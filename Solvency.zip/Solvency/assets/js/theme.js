$(window).scroll(function () {
    50 <= $(this).scrollTop() ? $("#return-to-top").fadeIn(200) : $("#return-to-top").fadeOut(200)
}), $("#return-to-top").on("click", function () {
    $("body,html").animate({
        scrollTop: 0
    }, 500)
});
// Menu JS
if ($(".responsive-nav-toggle").length) {
    $(".responsive-nav-toggle").on("click", function (e) {
        e.preventDefault();
        $(".navigation-mobile-wrapper").toggleClass("expanded");
    });
}
if ($(".mobile-navigation-container .navigation-menu-list").length) {
    let dropdownAnchor = $(
        ".mobile-navigation-container .navigation-menu-list .dropdown > a"
    );
    dropdownAnchor.each(function () {
        let self = $(this);
        let toggleBtn = document.createElement("BUTTON");
        toggleBtn.setAttribute("aria-label", "dropdown toggler");
        toggleBtn.innerHTML = "<i class='fa fa-angle-down'></i>";
        self.append(function () {
            return toggleBtn;
        });
        self.find("button").on("click", function (e) {
            e.preventDefault();
            let self = $(this);
            self.toggleClass("expanded");
            self.parent().toggleClass("expanded");
            self.parent().parent().children("ul").slideToggle();
        });
    });
}
$(window).on("scroll", function () {
    if ($(".scroll-menu").length) {
        var headerScrollPos = 130;
        var stricky = $(".scroll-menu");
        if ($(window).scrollTop() > headerScrollPos) {
            stricky.addClass("stricky-fixed");
        } else if ($(this).scrollTop() <= headerScrollPos) {
            stricky.removeClass("stricky-fixed");
        }
    }
    if ($(".scroll-to-top").length) {
        var strickyScrollPos = 100;
        if ($(window).scrollTop() > strickyScrollPos) {
            $(".scroll-to-top").fadeIn(500);
        } else if ($(this).scrollTop() <= strickyScrollPos) {
            $(".scroll-to-top").fadeOut(500);
        }
    }
});

// Theme Slider JS

$('.theme-slider').owlCarousel({
    loop: true,
    // margin: 10,
    responsiveClass: true,
    dots: true,
    slideSpeed: 300,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    autoplay: true,
    nav: true,
    responsive: {
        0: {
            items: 1,
            nav: false,
        },
        480: {
            items: 1,
            nav: false
        },
        600: {
            items: 1,
        },
        1000: {
            items: 1,
        }
    }
});

$('.partner-carousel').owlCarousel({
    loop: true,
    // margin: 10,
    responsiveClass: true,
    dots: true,
    slideSpeed: 300,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    autoplay: true,
    nav: false,
    responsive: {
        0: {
            items: 2,
            dots: false
        },
        480: {
            items: 2,
            dots: false,
        },
        600: {
            items: 3,
            dots: false,
        },

        1000: {
            items: 5,
        }
    }
});

// ======================= TESTIMONIAL  ======================= //

if ($('#testimonial').length > 0) {
    $("#testimonial").owlCarousel({
        dots: true,
        loop: true,
        autoplay: true,
        slideSpeed: 2000,
        margin: 0,
        responsiveClass: true,
        nav: false,
        navText: ["<i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>", "<i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>"],
        responsive: {
            0: {
                items: 1,
                nav: false,
                dotsEach: 2,
            },
            480: {
                items: 1,
                nav: false,
                dotsEach: 2,
            },
            600: {
                items: 1,
                nav: false,
                dotsEach: 2
            },
            1000: {
                items: 2,
                nav: false,
                margin: 0
            }
        }
    });
}


// Scroll to a Specific Div



// Team Slider JS
// $('.team-carousel').owlCarousel({
//     loop: true,
//     margin: 20,
//     nav: false,
//     dots: true,
//     smartSpeed: 1000,
//     autoplay: true,
//     autoplayTimeout: 4000,
//     autoplayHoverPause: true,
//     responsive: {
//         0: {
//             items: 1,
//         },
//         768: {
//             items: 2,
//         },
//         992: {
//             items: 3,
//         }
//     }
// });

// if ($(".mobile-nav__container").length) {
//     let navContent = document.querySelector(".main-menu").innerHTML;
//     let mobileNavContainer = document.querySelector(".mobile-nav__container");
//     mobileNavContainer.innerHTML = navContent;
// }

// if ($(".mobile-nav__container .main-menu__list").length) {
//     let dropdownAnchor = $(
//         ".mobile-nav__container .main-menu__list .dropdown > a"
//     );
//     dropdownAnchor.each(function () {
//         let self = $(this);
//         let toggleBtn = document.createElement("BUTTON");
//         toggleBtn.setAttribute("aria-label", "dropdown toggler");
//         toggleBtn.innerHTML = "<i class='fa fa-angle-down'></i>";
//         self.append(function () {
//             return toggleBtn;
//         });
//         self.find("button").on("click", function (e) {
//             e.preventDefault();
//             let self = $(this);
//             self.toggleClass("expanded");
//             self.parent().toggleClass("expanded");
//             self.parent().parent().children("ul").slideToggle();
//         });
//     });
// }

// if ($(".mobile-nav__toggler").length) {
//     $(".mobile-nav__toggler").on("click", function (e) {
//         e.preventDefault();
//         $(".mobile-nav__wrapper").toggleClass("expanded");
//     });
// }
